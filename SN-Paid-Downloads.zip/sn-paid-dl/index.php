﻿<?php

/*
Plugin Name: درگاه پرداخت و کیف پول الکترونیک - افزونه دانلود به ازای پرداخت
Version: 1.0.0
Description: تنظیمات درگاه پرداخت  برای افزونه دانلود به ازای پرداخت
Plugin URI: https://
Author: 
Author URI: https://
*/

require_once('class-paid-downloads-sn.php');
